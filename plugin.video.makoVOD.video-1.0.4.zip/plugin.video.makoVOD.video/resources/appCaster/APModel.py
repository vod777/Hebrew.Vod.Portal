# -*- coding: utf-8 -*-
'''
Created on 23/01/2012

@author: shai
'''
import types

class APModel(object):
    
    innerDictionary = {}


    def __init__(self):
        '''
        Constructor
        '''
  
    def get(self, lookfor = ''):
        return self.__get(lookfor, self.innerDictionary)
    
    
    # private method
    def __get(self, lookfor = '', dictionary = {}):
        if None == lookfor:
            return ''
        result = ''
        for key in dictionary.keys():
            if key == lookfor:
                return dictionary[key]
            try:
                evaluate = eval("("+dictionary[key]+")")
                if isinstance(evaluate, types.DictType):
                    result = self.__get(lookfor, evaluate)
                    if result != '':
                        break;
            except:
                pass
        
        # if its not a key in the innerDictionary and not a key in one of the dictionaries included
        # IN the dictionary it will return an empty value.
        return result
               
                
                
    