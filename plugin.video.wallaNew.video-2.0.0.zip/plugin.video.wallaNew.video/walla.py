# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from video.walla.co.il
"""
import urllib, re, xbmc, xbmcplugin, xbmcaddon, os, sys

##General vars
__plugin__ = "walla"
__author__ = "Shai Bentin"

__settings__ = xbmcaddon.Addon(id='plugin.video.wallaNew.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

from common import *

def CATEGORIES():

    ## add manual series which are not categorized
    hardcoded = {'0000001':'0000001', '0000002':'0000002'}
    for item, module in hardcoded.iteritems():
        iconImage = xbmc.translatePath(os.path.join(__PLUGIN_PATH__, 'cache', 'images', 'wallaBase', item + '.png'))
        addDir(__language__(int(item)), item, 1, iconImage, module)
    ## add from dynamic menu
    page = getData('http://video.walla.co.il/')
    matches = re.compile('<div class="right cube".*?><a href="(.*?)".*?title="(.*?)".*?style="background: url\((.*?)\)').findall(page)
    for id, name, img in matches:
        iconImage = getImage(img, 'wallaBase')
        elementId = re.compile('http://([^\.]+)\.(.*?)\/\?w=.*?(\d+)').findall(id)
        if (len(elementId)) == 1:
            addDir(name,id,1,iconImage,elementId[0][2])
        else:
            elementId = re.compile('http://([^\.]+)\.').findall(id)
            addDir(name,id,1,iconImage,elementId[0])
    
    matches = re.compile('<div class="right bottomCube".*?><a href="(.*?)".*?title="(.*?)".*?style="background: url\((.*?)\)').findall(page)
    for id, name, img in matches:
        iconImage = getImage(img, 'wallaBase')
        elementId = re.compile('http://([^\.]+)\.(.*?)\/\?w=.*?(\d+)').findall(id)
        if (len(elementId)) == 1:
            addDir(name,id,1,iconImage,elementId[0][2])
        else:
            elementId = re.compile('http://([^\.]+)\.').findall(id)
            addDir(name,id,1,iconImage,elementId[0])
            
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
    
if mode==None or url==None or len(url)<1:
        CATEGORIES()

else:
        xbmc.log('in walla %s' % (module), xbmc.LOGDEBUG)
        manager = getattr(__import__('module_' + module.lower()), 'manager_' + module)()
        manager.work(mode, url, name, page)
        


xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( __PLUGIN_PATH__,"fanart.jpg") ))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
