# -*- coding: utf-8 -*-

'''
Created on 16/05/2011
Walla Series
@author: shai
'''
import xbmcaddon

__settings__ = xbmcaddon.Addon(id='plugin.video.wallaNew.video')
__language__ = __settings__.getLocalizedString
__BASE_URL__ = 'http://video.walla.co.il/'
__NAME__ = '0000001'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_0000001:
    
    def __init__(self):
        self.MODES = common.enum(GET_CATEGORIES=1, GET_SERIES_LIST=2, GET_EPISODES_LIST=3, GET_SEASON_EPISODES=4)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CATEGORIES):
            self.getCategories()
        elif (mode==self.MODES.GET_SERIES_LIST):
            self.getSeriesList(url)
        elif(mode==self.MODES.GET_EPISODES_LIST):
            self.getEpisodeList(url)
        elif(mode==self.MODES.GET_SEASON_EPISODES):
            self.getSeasonEpisodes(url)

    def getCategories(self):
        ## get all the series base url
        page = common.getData(__BASE_URL__ + '?w=/4552')
        tabNavBlock = re.compile('<div class="tabsNav"><div class="right">.*?</div>').findall(page)
        categories = re.compile('<span.*?>.*?</span><a href="(.*?)".*?>(.*?)</a').findall(tabNavBlock[0])
        i = 0
        for category, title in categories:
            if i > 0:
                common.addDir(title, __BASE_URL__ + category, self.MODES.GET_SERIES_LIST, 'DefaultFolder.png', __NAME__)
            i+=1
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        xbmc.executebuiltin("Container.SetViewMode(501)")
                  
    def getSeriesList(self, url):
        ## get all the series base url
        baseUrl = common.getData(url)
        urls = re.compile('(<div class="img".*?</div>)').findall(baseUrl)
        for url in urls:
            items = re.compile('<a href="(.*?)".*?<img src="(.*?)".*?<span.*?>(.*?)<').findall(url)
            for path, image, title in items:
                if not path.startswith("http://"):
                    path = __BASE_URL__ + path
                common.addDir(title, path, self.MODES.GET_EPISODES_LIST, image, __NAME__)
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        xbmc.executebuiltin("Container.SetViewMode(500)")
        
    def getSeasonEpisodes(self, url):
        main_page = common.getData(url)
        self.showEpisodes(main_page)
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(501)")
        
    def getEpisodeList(self, url):
        main_page = common.getData(url)
        tabNavBlock = re.compile('<div class="tabsNav"><div class="right">.*?</div>').findall(main_page)
        seasons = re.compile('<span.*?>.*?</span><a href="(.*?)".*?>(.*?)</a').findall(tabNavBlock[0])
        i = 0
        if len(seasons) > 2:
            for season, title in seasons:
                if i < (len(seasons) - 1):
                    common.addDir(title, __BASE_URL__ + season, self.MODES.GET_SEASON_EPISODES, 'DefaultFolder.png', __NAME__)
                i+=1
        else:
            self.showEpisodes(main_page)
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(501)")
        
    def showEpisodes(self, main_page):
        episodes = re.compile('<div class="right item_small " style="">.*?<a href="(.*?)".*?</span><img src="(.*?)".*?<a.*?>(.*?)<').findall(main_page)
        for url, img, title in episodes:
            page = common.getData(__BASE_URL__ + url + '/@@/video/flv_pl')
            titleMatches = re.compile('<title>(.*?)</title>(.*)<subtitle>(.*?)<').findall(page)
            if (len(titleMatches)) == 1:
                title = titleMatches[0][0]
                images = re.compile('<preview_pic>(.*?)</preview_pic>').findall(page)
                if (len(images)) >= 1:
                    iconImage = images[0]
                details = re.compile('<synopsis>(.*?)</synopsis>').findall(page)
                if (len(details)) > 0:
                    epiDetails = details[0]
                
                timeInSeconds = re.compile('<duration>(.*?)</duration>').findall(page)
                if not timeInSeconds == None and not len(timeInSeconds[0]) <= 0:
                    time = int(timeInSeconds[0]) / 60
                else:
                    time = '00:00'
                url = 'rtmp://waflaWBE.walla.co.il/ app=vod/ swfvfy=true swfUrl=http://i.walla.co.il/w9/swf/video_swf/vod/walla_vod_player_adt.swf?95 tcurl=rtmp://waflaWBE.walla.co.il/vod/ pageurl=http://walla.co.il/ playpath=' + re.compile('<src>(.*?)</src>').findall(page)[0]
                common.addLink(title, url, iconImage, str(time), epiDetails)
        nextPage = re.compile('class="in_blk p_r".*?href="(.*?)"').findall(main_page)
        if (len(nextPage)) > 0:
            common.addDir(__language__(30001), __BASE_URL__ + nextPage[0], self.MODES.GET_SEASON_EPISODES, 'DefaultFolder.png', __NAME__)