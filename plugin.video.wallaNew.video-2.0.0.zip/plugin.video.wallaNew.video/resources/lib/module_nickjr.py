# -*- coding: utf-8 -*-

'''
Created on 30/04/2011

@author: shai
'''
__BASE_URL__ = 'http://nickjr.walla.co.il/'
__NAME__ = 'nickjr'
__PATTERN__ = '<div class="title w4b"><a href="(.*?)"'
__PATTERN_MORE__ = 'class="p_r"\sstyle=""\shref="(.*?)"'
__PATTERN_FEATURED__ ='<div class="title w5b mt5"><a href="(.*?)"'

import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys
import common

class manager_nickjr:
    
    def __init__(self):
        self.MODES = common.enum(GET_SERIES_LIST=1, GET_EPISODES_LIST=2)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_SERIES_LIST):
            self.getSeriesList()
        elif(mode==self.MODES.GET_EPISODES_LIST):
            common.getEpisodeList(__BASE_URL__, url, __PATTERN__, __NAME__, self.MODES.GET_EPISODES_LIST, __PATTERN_FEATURED__, __PATTERN_MORE__)
            
    def getSeriesList(self):
        ## get all the series base url
        urls = common.getMatches(__BASE_URL__,'<a id="opc" href="(.*?)"')
        print urls
        ## for each series we get the series page to parse all the info from
        for path in urls:
            page = common.getData(__BASE_URL__ + path)
            titleMatches = re.compile('class="stripe_title w7b white">\s*(.*?)\s*</h1>\s*<img src="(.*?)"').findall(page)
            if len(titleMatches) == 0:
                # try a different possibility
                titleMatches = re.compile('class="stripe_title w7b white">.*?>(.*?)<.*?src="(.*?)"').findall(page)
            details = re.compile('class="w3 nohvr" style="line-height:17px;">(.*?)<').findall(page)
            if (len(details)) > 0:
                summary = details[0]
            else:
                summary = ''
            if (len(titleMatches)) == 1:
                title = titleMatches[0][0]
                iconImage = common.getImage(titleMatches[0][1],__NAME__)
                urlMatch = re.compile('class="w6b" href="(.*?)">').findall(page)
                if (len(urlMatch)) > 0:
                    common.addDir(title, __BASE_URL__ + urlMatch[0], self.MODES.GET_EPISODES_LIST, iconImage, __NAME__, summary)                    
            
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        
        
#    def getEpisodeList(self, inUrl):
#        ## get all the rest of the episodes
#        urls = common.getMatches(inUrl,'<div class="title w4b"><a href="(.*?)"')
#        ## for each episode we get the episode page to parse all the info from
#        for path in urls:
#            page = common.getData(__BASE_URL__+'/' + path)
#            titleMatches = re.compile('<h1 class="w5b"\s(.*?)>(.*?)<').findall(page)
#            if (len(titleMatches)) == 1:
#                title = titleMatches[0][1]
#                images = re.compile('class="left_row  selected_left_row bgclr2 zoom1"><div(.*?)url\(\'(.*?)\'').findall(page)
#                if (len(images)) == 1:
#                    iconImage = images[0][1]
#                details = re.compile('<div class="wp-0-b w3">(.*?)<').findall(page)
#                if (len(details)) > 0:
#                    epiDetails = details[0]
#                
#                flashVars = re.compile('flashvars","(.*?)",').findall(page)[0]
#                timeInSeconds = re.compile('duration=((\d)+)').findall(flashVars)[0][0]
#                time = int(timeInSeconds) / 60
#                url = 'http://i.walla.co.il/w9/swf/video_swf/vod/walla_vod_player_adt.swf?95' + flashVars
#                common.addLink(title, url, iconImage, str(time), epiDetails)
#        nextPage = re.compile('class="p_r"\sstyle=""\shref="(.*?)"').findall(mainPage)
#        if (len(nextPage)) > 0:
#            common.addDir(common.__language__(30001), __BASE_URL__ + '/' + nextPage[0], self.MODES.GET_EPISODES_LIST, 'DefaultFolder.png', __NAME__)
#        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
