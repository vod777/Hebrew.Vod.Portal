# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''
import xbmcaddon

__settings__ = xbmcaddon.Addon(id='plugin.video.wallaNew.video')
__language__ = __settings__.getLocalizedString

__BASE_URL__ = 'http://video.walla.co.il/'
__NAME__ = '0000002'

import urllib, re, sys
import xbmc, xbmcplugin, xbmcgui
import common

class manager_0000002:
    
    def __init__(self):
        self.MODES = common.enum(GET_GENRE=1, GET_EPISODES_LIST=2, PLAY_MOVIE=3)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_GENRE):
            self.getGenere()
        elif (mode==self.MODES.GET_EPISODES_LIST):
            self.getEpisodeList(url)
        elif (mode==self.MODES.PLAY_MOVIE):
            self.playMovie(url)
    
    def getGenere(self):
        ## get all the series base url
        page = common.getData(__BASE_URL__ + '?w=/2224')
        tabNavBlock = re.compile('<div class="tabsNav"><div class="right">.*?</div>').findall(page)
        categories = re.compile('<span.*?>.*?</span><a href="(.*?)".*?>(.*?)</a').findall(tabNavBlock[0])
        i = 0
        for category, title in categories:
            if i > 0:
                common.addDir(title, __BASE_URL__ + category, self.MODES.GET_EPISODES_LIST, 'DefaultFolder.png', __NAME__)
            i+=1
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        xbmc.executebuiltin("Container.SetViewMode(501)")
                
    def getEpisodeList(self, url):
        ## get all the series base url
        baseUrl = common.getData(url)
        urls = re.compile('(<div class="img".*?</div>)').findall(baseUrl)
        for url in urls:
            items = re.compile('<a href="(.*?)".*?<img src="(.*?)".*?<span.*?>(.*?)<').findall(url)
            for path, image, title in items:
                if not path.startswith("http://"):
                    path = __BASE_URL__ + path
                common.addVideoLink(title, path, self.MODES.PLAY_MOVIE, image, __NAME__)
        nextPage = re.compile('class="in_blk p_r".*?href="(.*?)"').findall(baseUrl)
        if (len(nextPage)) > 0:
            common.addDir(__language__(30001), __BASE_URL__ + nextPage[0], self.MODES.GET_EPISODES_LIST, 'DefaultFolder.png', __NAME__)
        xbmc.executebuiltin("Container.SetViewMode(500)")
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')        
        
    def playMovie(self, url):
        print url
        page = common.getData(url + '/@@/video/flv_pl', 0)
        print page
        titleMatches = re.compile('<title>(.*?)</title><subtitle>(.*?)<').findall(page)
        if (len(titleMatches)) == 1:
            title = titleMatches[0][0]
            images = re.compile('<preview_pic>(.*?)</preview_pic>').findall(page)
            if (len(images)) >= 1:
                iconImage = images[0]
            details = re.compile('<synopsis>(.*?)</synopsis>').findall(page)
            if (len(details)) > 0:
                epiDetails = details[0]
            
            timeInSeconds = re.compile('<duration>(.*?)</duration>').findall(page)
            if not timeInSeconds == None and not len(timeInSeconds[0]) <= 0:
                time = int(timeInSeconds[0]) / 60
            else:
                time = '00:00'
            movieUrls = re.compile('<src>(.*?)</src>').findall(page)
            movieUrl = movieUrls[len(movieUrls) - 1]
            url = 'rtmp://waflaWBE.walla.co.il/vod/ playpath=' + movieUrl + ' swfvfy=true swfUrl=http://i.walla.co.il/w9/swf/video_swf/vod/walla_vod_player_adt.swf?134 pageurl=' + __BASE_URL__ + url
            listItem = xbmcgui.ListItem(title, 'DefaultFolder.png', iconImage, path=url)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            listItem.setInfo(type='Video', infoLabels={ "Title": title, "Duration": str(time), "Plot": urllib.unquote(epiDetails)})
            listItem.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)